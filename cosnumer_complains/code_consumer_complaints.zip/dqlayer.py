from pyspark.sql import SparkSession
import json
import csv
from pyspark.sql.functions import col
from dependencies.dqRules import DQCheck

def readDBConfig(dbConfigPath,db_id):

    f = open(dbConfigPath)
    configData = json.load(f)
    return configData[db_id]

def processTable(table_info):

    try:
        # Read source csv 
        src_file_path = table_info['src_file_path']
        src_df = spark.read.csv(header=True,path=src_file_path)

        src_df = src_df.limit(5)
        temp = DQCheck()

        good,bad = temp.isNotNull(src_df,['Company','State','Sub-product'])
        print('__good__data__')
        good.show(5)
        print('__bad__data__')
        bad.show(1)


        good,bad = temp.hasMaxLength(good,'Company',20)
        print('__good__data__')
        good.show(5)
        print('__bad__data__')
        bad.show(1)

    except Exception as e:
        print(str(e))

if __name__ == "__main__":

    # Create Spark Session 
    global spark
    spark = SparkSession.builder.getOrCreate()

    # Set log level
    spark.sparkContext.setLogLevel("ERROR")
    
    # dim_company
    table_info = {}
    table_info['table_name'] = 'dim_company'
    table_info['dbConfigPath'] = "/home/tms/tmsCodeGround/awsstudy/consumer_complaints/configs/dbConfig.json"
    table_info['db_id'] = 'postgres_datamart'
    table_info['src_file_path'] = '/home/tms/tmsCodeGround/awsstudy/consumer_complaints/data/complaints.csv'
    table_info['mapping_path'] = "/home/tms/tmsCodeGround/awsstudy/consumer_complaints/mappings/mapping_dim_company.csv"
    processTable(table_info)
