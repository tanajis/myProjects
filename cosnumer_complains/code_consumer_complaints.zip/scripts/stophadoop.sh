
#Install hadoop from https://www.michael-noll.com/tutorials/running-hadoop-on-ubuntu-linux-single-node-cluster/

cd /home/tms/tmsCodeGround/myInstallDir/hadoop-2.7.3/sbin
./stop-yarn.sh
./stop-dfs.sh

#Start Spark
cd /home/tms/tmsCodeGround/myInstallDir/spark-2.3.2-bin-hadoop2.7/sbin
./stop-all.sh